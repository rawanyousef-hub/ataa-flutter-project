package com.example.project_ataa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
